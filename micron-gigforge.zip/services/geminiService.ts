import { GoogleGenAI, Type } from "@google/genai";
import { Project, DuplicateCheckResult } from "../types";

// Initialize Gemini Client
// Note: In a real app, ensure process.env.API_KEY is available. 
// For this mockup, we assume the environment is set up correctly as per instructions.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const checkForDuplicateProjects = async (
  newTitle: string,
  newDescription: string,
  existingProjects: Project[]
): Promise<DuplicateCheckResult> => {
  
  // We simply pass the metadata of existing projects to the model context.
  // In a production app with thousands of projects, you would use a Vector Database (embeddings)
  // to retrieve only relevant projects first. For this mockup, passing the list is fine.
  
  const projectListContext = existingProjects.map(p => ({
    id: p.id,
    title: p.title,
    description: p.description,
    department: p.department
  }));

  const prompt = `
    You are a project manager assistant at Micron Technology. 
    Your goal is to prevent duplicate work. 
    
    I will provide a list of EXISTING PROJECTS and a NEW PROJECT PROPOSAL.
    Analyze if the NEW PROJECT PROPOSAL is semantically similar (solves the same problem or asks for the same tool) to any of the EXISTING PROJECTS.
    
    EXISTING PROJECTS:
    ${JSON.stringify(projectListContext)}
    
    NEW PROJECT PROPOSAL:
    Title: ${newTitle}
    Description: ${newDescription}
    
    Respond in JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isDuplicate: { type: Type.BOOLEAN },
            reason: { type: Type.STRING, description: "Explanation of why it is a duplicate or unique." },
            similarProjectIds: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "Array of IDs of projects that are very similar." 
            }
          },
          required: ["isDuplicate", "reason", "similarProjectIds"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      isDuplicate: result.isDuplicate || false,
      reason: result.reason || "Analysis complete.",
      similarProjectIds: result.similarProjectIds || []
    };

  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback if API fails (e.g. no key provided in demo env)
    return {
      isDuplicate: false,
      reason: "Could not verify duplicates at this time (AI Service Unavailable).",
      similarProjectIds: []
    };
  }
};

export const generateHandoverDocs = async (
  projectTitle: string,
  repoUrl: string,
  solutionCode: string
): Promise<string> => {
  const prompt = `
    You are a Senior Technical Writer at Micron. 
    A developer has finished a script/tool for the project: "${projectTitle}".
    
    The code is hosted at: ${repoUrl}
    
    They have provided the main logic snippet or context below:
    "${solutionCode}"
    
    Generate a clean, professional "MAINTENANCE.md" file content.
    
    Structure:
    1. **Project Title & Repo Link**: Start with the title and a git clone command.
    2. **Overview**: What this script/tool does (inferred from project title and code).
    3. **Installation/Setup**: Standard setup steps (e.g. pip install requirements.txt).
    4. **Logic Flow**: Explanation of how the code works.
    5. **Support**: Placeholder for contact info.
    
    Keep it concise and formatted in Markdown.
    
    RAW CODE CONTEXT:
    ${solutionCode}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt
    });
    return response.text || "## Error generating documentation.";
  } catch (error) {
    console.error("Gemini Handover Error:", error);
    return "## Error: AI Service Unavailable.\nPlease manually write the documentation.";
  }
};